def hello_world(number):
    print("Hello, world! My name is", name)

hello_world("<Jericho, Huelar>")
